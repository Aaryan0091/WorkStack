// WorkStack Tab Tracker - Popup

document.addEventListener('DOMContentLoaded', async () => {
  const statusDot = document.getElementById('statusDot')
  const statusText = document.getElementById('statusText')
  const toggleBtn = document.getElementById('toggleBtn')
  const toggleBtnText = document.getElementById('toggleBtnText')
  const dashboardBtn = document.getElementById('dashboardBtn')
  const addToCollectionBtn = document.getElementById('addToCollectionBtn')
  const addBookmarkBtn = document.getElementById('addBookmarkBtn')
  const currentTabSection = document.getElementById('currentTabSection')
  const currentTabTitleEl = document.getElementById('currentTabTitle')
  const currentTabUrlEl = document.getElementById('currentTabUrl')
  const todayTabs = document.getElementById('todayTabs')
  const todayTime = document.getElementById('todayTime')
  const notification = document.getElementById('notification')
  const notificationIcon = document.getElementById('notificationIcon')
  const notificationText = document.getElementById('notificationText')

  // Modal elements
  const collectionModal = document.getElementById('collectionModal')
  const closeModalBtn = document.getElementById('closeModalBtn')
  const collectionList = document.getElementById('collectionList')
  const COLLECTIONS_CACHE_KEY = 'workstackCollectionsCache'
  const COLLECTIONS_CACHE_TTL = 30000
  let inMemoryCollectionsCache = null
  let collectionsFetchPromise = null

  // Get current active tab
  const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true })
  const tabUrl = activeTab?.url
  const tabTitle = activeTab?.title

  // Get current status from background script with timeout
  let statusResponse = { isTracking: false, isPaused: false, hasSavedSession: false, currentTab: null, sessionTabs: [] }

  try {
    statusResponse = await Promise.race([
      chrome.runtime.sendMessage({ action: 'getStatus' }),
      new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout')), 2000))
    ])
  } catch {
    // Failed to get status, will use storage fallback
    // Try to load from storage as fallback
    chrome.storage.local.get(['isTracking', 'isPaused'], (result) => {
      statusResponse.isTracking = result.isTracking || false
      statusResponse.isPaused = result.isPaused || false
      updateUI()
    })
  }

  function updateUI() {
    if (statusResponse.isTracking) {
      statusDot.className = 'dot active'
      statusText.textContent = statusResponse.isPaused ? 'Tracking Paused' : 'Tracking Active'
      toggleBtnText.textContent = 'Stop Tracking'
      toggleBtn.classList.add('active')

      if (statusResponse.currentTab) {
        currentTabSection.style.display = 'block'
        currentTabTitleEl.textContent = statusResponse.currentTab.title || 'Untitled'
        currentTabUrlEl.textContent = statusResponse.currentTab.url
      }
    } else {
      statusDot.className = 'dot inactive'
      statusText.textContent = 'Tracking Paused'
      toggleBtnText.textContent = 'Start Tracking'
      toggleBtn.classList.remove('active')
      currentTabSection.style.display = 'none'
    }
  }

  updateUI()

  function getStorage(keys) {
    return new Promise((resolve) => {
      chrome.storage.local.get(keys, resolve)
    })
  }

  function setStorage(values) {
    return new Promise((resolve) => {
      chrome.storage.local.set(values, resolve)
    })
  }

  // Load today's summary from storage
  chrome.storage.local.get(['todayTabs', 'todaySeconds'], (result) => {
    todayTabs.textContent = result.todayTabs || '0'

    const seconds = result.todaySeconds || 0
    const minutes = Math.floor(seconds / 60)
    const hours = Math.floor(minutes / 60)

    if (hours > 0) {
      todayTime.textContent = `${hours}h ${minutes % 60}m`
    } else if (minutes > 0) {
      todayTime.textContent = `${minutes}m`
    } else {
      todayTime.textContent = `${seconds}s`
    }
  })

  // Show notification
  function showNotification(message, type = 'success') {
    notification.className = `notification ${type}`
    notificationIcon.textContent = type === 'success' ? '✓' : '✕'
    notificationText.textContent = message
    notification.style.display = 'flex'

    // Hide after 3 seconds
    setTimeout(() => {
      notification.style.display = 'none'
    }, 3000)
  }

  // Close modal
  function closeModal() {
    collectionModal.style.display = 'none'
  }

  closeModalBtn.addEventListener('click', closeModal)

  // Close modal when clicking outside
  collectionModal.addEventListener('click', (e) => {
    if (e.target === collectionModal) {
      closeModal()
    }
  })

  // Toggle tracking button
  toggleBtn.addEventListener('click', async () => {
    const result = await chrome.runtime.sendMessage({ action: 'toggleTracking' })

    if (result.success) {
      statusResponse.isTracking = result.isTracking
      updateUI()

      chrome.storage.local.get(['todayTabs'], (storageResult) => {
        const tabs = (storageResult.todayTabs || 0) + (result.isTracking ? 0 : 0)
        chrome.storage.local.set({ todayTabs: tabs })
      })
    }
  })

  // Get API base URL from storage with smart fallback
  function getApiBaseUrl(callback) {
    chrome.storage.local.get(['apiBaseUrl'], (result) => {
      if (result.apiBaseUrl) {
        callback(result.apiBaseUrl)
      } else {
        // If no stored URL, extension may not be properly connected
        // Show error to user
        callback(null)
      }
    })
  }

  function renderCollections(collections) {
    if (!collections || collections.length === 0) {
      collectionList.innerHTML = '<div class="collection-item-empty">No collections found.<br>Create one on the website first!</div>'
      return
    }

    collectionList.innerHTML = ''
    collections.forEach(collection => {
      const itemDiv = document.createElement('div')
      itemDiv.className = 'collection-item'
      itemDiv.dataset.id = collection.id
      itemDiv.dataset.name = collection.name

      const infoDiv = document.createElement('div')
      infoDiv.className = 'collection-item-info'

      const nameDiv = document.createElement('div')
      nameDiv.className = 'collection-item-name'
      nameDiv.textContent = collection.name
      infoDiv.appendChild(nameDiv)

      if (collection.description) {
        const descDiv = document.createElement('div')
        descDiv.className = 'collection-item-desc'
        descDiv.textContent = collection.description
        infoDiv.appendChild(descDiv)
      }

      itemDiv.appendChild(infoDiv)

      const badgeSpan = document.createElement('span')
      badgeSpan.className = `collection-item-badge ${collection.is_public ? 'public' : 'private'}`
      badgeSpan.textContent = collection.is_public ? 'Public' : 'Private'
      itemDiv.appendChild(badgeSpan)

      itemDiv.addEventListener('click', () => {
        addToCollection(collection.id, collection.name)
      })

      collectionList.appendChild(itemDiv)
    })
  }

  function readCachedCollections(baseUrl, token) {
    const now = Date.now()

    if (
      inMemoryCollectionsCache &&
      inMemoryCollectionsCache.baseUrl === baseUrl &&
      inMemoryCollectionsCache.token === token &&
      now - inMemoryCollectionsCache.timestamp < COLLECTIONS_CACHE_TTL
    ) {
      return inMemoryCollectionsCache.collections
    }

    return null
  }

  async function fetchCollections(baseUrl, token, { forceRefresh = false } = {}) {
    if (!forceRefresh) {
      const cachedCollections = readCachedCollections(baseUrl, token)
      if (cachedCollections) {
        return cachedCollections
      }

      const storageResult = await getStorage([COLLECTIONS_CACHE_KEY])
      const storedCache = storageResult[COLLECTIONS_CACHE_KEY]
      if (
        storedCache &&
        storedCache.baseUrl === baseUrl &&
        storedCache.token === token &&
        Date.now() - storedCache.timestamp < COLLECTIONS_CACHE_TTL
      ) {
        inMemoryCollectionsCache = storedCache
        return storedCache.collections || []
      }
    }

    if (collectionsFetchPromise) {
      return collectionsFetchPromise
    }

    collectionsFetchPromise = (async () => {
      const response = await fetch(`${baseUrl}/api/collections?all=true&minimal=true`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      })

      if (!response.ok) {
        throw new Error('Failed to fetch collections')
      }

      const data = await response.json()
      const collections = data.collections || []
      const cachePayload = {
        baseUrl,
        token,
        timestamp: Date.now(),
        collections
      }

      inMemoryCollectionsCache = cachePayload
      await setStorage({ [COLLECTIONS_CACHE_KEY]: cachePayload })

      return collections
    })()

    try {
      return await collectionsFetchPromise
    } finally {
      collectionsFetchPromise = null
    }
  }

  async function preloadCollections() {
    const { apiBaseUrl, authToken } = await getStorage(['apiBaseUrl', 'authToken'])
    if (!apiBaseUrl || !authToken) return

    try {
      await fetchCollections(apiBaseUrl, authToken)
    } catch {
      // Silent background preload failure - user can retry from the button flow.
    }
  }

  preloadCollections()

  // Dashboard button
  dashboardBtn.addEventListener('click', () => {
    getApiBaseUrl((baseUrl) => {
      if (baseUrl) {
        chrome.tabs.create({ url: `${baseUrl}/tracked-activity` })
      } else {
        showNotification('Please visit WorkStack website to connect', 'error')
      }
    })
  })

  // Add to Collection button - show collection selector modal
  addToCollectionBtn.addEventListener('click', async () => {

    if (!tabUrl) {
      showNotification('Cannot add this page', 'error')
      return
    }

    // Check if there's a valid URL (not chrome://, etc.)
    if (tabUrl.startsWith('chrome://') ||
        tabUrl.startsWith('chrome-extension://') ||
        tabUrl.startsWith('edge://') ||
        tabUrl.startsWith('about:')) {
      showNotification('Cannot add special pages', 'error')
      return
    }

    getApiBaseUrl(async (baseUrl) => {
      if (!baseUrl) {
        showNotification('Please connect extension from WorkStack website', 'error')
        collectionModal.style.display = 'none'
        return
      }

      const { authToken: token } = await getStorage(['authToken'])

      if (!token) {
        showNotification('Not logged in. Visit WorkStack to login.', 'error')
        collectionModal.style.display = 'none'
        return
      }

      // Show loading state in modal
      collectionModal.style.display = 'flex'
      const cachedCollections = readCachedCollections(baseUrl, token)
      if (cachedCollections) {
        renderCollections(cachedCollections)
      } else {
        collectionList.innerHTML = '<div class="collection-item-loading">Loading collections...</div>'
      }

      try {
        const collections = await fetchCollections(baseUrl, token)
        renderCollections(collections)

      } catch {
        // Show empty state - use DOM methods
        collectionList.innerHTML = ''
        const emptyDiv = document.createElement('div')
        emptyDiv.className = 'collection-item-empty'
        emptyDiv.innerHTML = 'Failed to load collections.\nTry refreshing the page.'
        collectionList.appendChild(emptyDiv)
      }
    })
  })

  // Add to selected collection
  async function addToCollection(collectionId, collectionName) {
    getApiBaseUrl(async (baseUrl) => {
      if (!baseUrl) {
        showNotification('Please connect extension from WorkStack website', 'error')
        closeModal()
        return
      }

      chrome.storage.local.get(['authToken'], async (result) => {
        const token = result.authToken

        // Show loading state - use DOM methods
        collectionList.innerHTML = ''
        const loadingDiv = document.createElement('div')
        loadingDiv.className = 'collection-item-loading'
        loadingDiv.textContent = 'Adding...'
        collectionList.appendChild(loadingDiv)

      try {
        let title = tabTitle || tabUrl
        if (!tabTitle) {
          try {
            const urlObj = new URL(tabUrl)
            title = urlObj.hostname
          } catch {
            title = tabUrl
          }
        }

        const bookmarkData = {
          url: tabUrl,
          title: title,
          collection_id: collectionId
        }

        const response = await fetch(`${baseUrl}/api/bookmarks`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify(bookmarkData)
        })

        const data = await response.json()

        if (response.ok) {
          closeModal()
          showNotification(`Added to "${collectionName}"!`, 'success')
        } else if (response.status === 401) {
          showNotification('Session expired. Click to reconnect.', 'error')
          closeModal()
        } else {
          showNotification(`Error: ${data.error || 'Failed'}`, 'error')
          closeModal()
        }
      } catch {
        showNotification('Failed to connect. Is app running?', 'error')
        closeModal()
      }
    })
    })
  }

  // Add as Bookmark button
  addBookmarkBtn.addEventListener('click', async () => {
    if (!tabUrl) {
      showNotification('Cannot bookmark this page', 'error')
      return
    }

    // Check if there's a valid URL (not chrome://, etc.)
    if (tabUrl.startsWith('chrome://') ||
        tabUrl.startsWith('chrome-extension://') ||
        tabUrl.startsWith('edge://') ||
        tabUrl.startsWith('about:')) {
      showNotification('Cannot bookmark special pages', 'error')
      return
    }

    // Show loading state
    const originalText = addBookmarkBtn.innerHTML
    addBookmarkBtn.textContent = 'Adding...'
    addBookmarkBtn.disabled = true

    // Get API base URL from storage
    getApiBaseUrl(async (baseUrl) => {
      if (!baseUrl) {
        showNotification('Please connect extension from WorkStack website', 'error')
        addBookmarkBtn.innerHTML = originalText
        addBookmarkBtn.disabled = false
        return
      }

      chrome.storage.local.get(['authToken'], async (result) => {
        const token = result.authToken

        if (!token) {
          showNotification('Not logged in. Visit WorkStack to login.', 'error')
          addBookmarkBtn.innerHTML = originalText
          addBookmarkBtn.disabled = false
          return
        }

        try {
          // Get the hostname for the title if no title available
          let title = tabTitle || tabUrl
          if (!tabTitle) {
            try {
              const urlObj = new URL(tabUrl)
              title = urlObj.hostname
            } catch {
              title = tabUrl
            }
          }

          const bookmarkData = {
            url: tabUrl,
            title: title,
            description: title, // Use title as description for AI tagging
            notes: null,
            folder_id: null
          }

          // Make API call to create bookmark
          const response = await fetch(`${baseUrl}/api/bookmarks`, {
            method: 'POST',
            headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify(bookmarkData)
        })

        const data = await response.json()

        if (response.ok) {
          showNotification('Bookmark added!', 'success')
        } else if (response.status === 409) {
          showNotification('Already bookmarked', 'error')
        } else if (response.status === 401) {
          showNotification('Session expired. Click to reconnect.', 'error')
        } else {
          showNotification(`Error: ${data.error || 'Failed'}`, 'error')
        }
      } catch {
        showNotification('Failed to connect. Is app running?', 'error')
      } finally {
        addBookmarkBtn.innerHTML = originalText
        addBookmarkBtn.disabled = false
      }
      })
    })
  })
})
